/*
Name :- kevin patel
Student number:- A00239407
This program contains encryption of string, average of array, array contains values and determines the value is true or false,
reverse of an array and a comparison of an array.

*/
import java.util.*;
public class ArrayTools {
    public static void main(String args[]) {
        Caesercipher();
        System.out.println("\n");
        Average();
        System.out.println("\n");
        Contains();
        System.out.println("\n");
        Reverse();
        System.out.println("\n");
        Compare();
        System.out.println("\n");

  }
  static void Caesercipher()
  {
      Scanner sc = new Scanner(System.in);
         System.out.println(" Enter a string to encrypt : ");//string enter by the user to encrypted
         String plaintext = sc.nextLine();//value assign by the user is stored
         System.out.println(" Enter a value to encrypt with : ");//Enter value by user for shifting.
         int shift = sc.nextInt();
         String ciphertext = "";//It is considered as return value.
         char alphabet;//It is taken for the single alphabet
         for(int i=0; i < plaintext.length();i++)/*for loop will runs until the length of the plaintext is not calculated */
         {
              // Shift one character at a time
             alphabet = plaintext.charAt(i);

             // if alphabet lies between a and z
             if(alphabet >= 'a' && alphabet <= 'z')
             {
              // shift alphabet
              alphabet = (char) (alphabet + shift);
              // if shift alphabet greater than 'z'
              if(alphabet > 'z') {
                 // reshift to starting position
                 alphabet = (char) (alphabet+'a'-'z'-1);
              }
              ciphertext = ciphertext + alphabet;
             }

             // if alphabet lies between 'A'and 'Z'
             else if(alphabet >= 'A' && alphabet <= 'Z') {
              // shift alphabet
              alphabet = (char) (alphabet + shift);

              // if shift alphabet greater than 'Z'
              if(alphabet > 'Z') {
                  //reshift to starting position
                  alphabet = (char) (alphabet+'A'-'Z'-1);
              }
              ciphertext = ciphertext + alphabet;
             }
             else {
              ciphertext = ciphertext + alphabet;
             }

     }
     System.out.println(" The encrypted string is : " + ciphertext);

  }

  static void Average()//This method will make an average of an array.
  {

        double[] arr = {19, 12.89, 16.5, 200, 13.7};//Array has ben assigned.
        double total = 0;//It will store the total of an array.

        for(int i=0; i<arr.length; i++){
        	total = total + arr[i];
        }
        double average = total / arr.length;//This will give the final answer and stored in aveerage.
          System.out.print("Testing method with [19 12.89 16.5 200 13.7 ]\n");
        System.out.format("The average is: %f", average);

}
 static void Contains()//This method will check that an array really contains the value .if yes then it will return true or false.
  {

        String [] array = {"hello", "world"};//new array
        List <String> list = Arrays.asList(array);
        if(list.contains("hello")) {
        System.out.println("true");
        }
        else{
        System.out.println("false");
        }

}
static void Reverse()//This method will reverse the whole Array
  {

        ArrayList array = new ArrayList();
        array.add("My");//values has been added to the array.
        array.add("Name");
        array.add("Is");
        array.add("kevin");
        array.add("patel");
        System.out.println("Before Reverse Order: " + array);
        Collections.reverse(array);//This will reverse the ArrayList.
        System.out.println("After Reverse Order: " + array);

}
static void Compare()//It will compare the values.
  {
    String str1 = "kevin";
	  String str2 = "kevin";
	  String str3 = "patel";

	   System.out.println(str1.compareTo(str2));
	    System.out.println(str2.compareTo(str3));

}

}
