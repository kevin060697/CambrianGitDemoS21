/*
Name: Kevin Patel
Student no: A00239407
This program allows a user to convert between different forms of measurement.

*/
import java.util.Scanner;

public class convert{

  public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);

    double b,mi,lb,in,kg,cm,km;
           b = sc.nextInt();
    System.out.println("Enter the value :"+b);
    String a = sc.nextLine();
    System.out.println("Enter unit to convert : "+a);

    if (a=="km"){
      mi = b*(1.61);
      System.out.println(+b"km is equal to "+mi" mi.");
    }
    else if (a=="kg") {
      lb=b*(0.45);
      System.out.println(+b"kg is equal to "+lb"lb.");
    }
    else if (a=="cm") {
      in=b*(2.54);
      System.out.println(+b"cm is equal to "+in"in.");
    }
    else if (a=="mi") {
      km=b*(0.62);
      System.out.println(+b"miles is equal to "+km"km.");
    }
    else if (a=="lb") {
      kg=b*(2.2);
      System.out.println(+b"lb is equal to "+kg"kg.");
    }
    else if (a=="in") {
      cm=b*(0.39);
      System.out.println(+b"inch is equal to "+cm"cm.");
    }else {
      System.out.println("Invalid input.");
    }
  }
}
